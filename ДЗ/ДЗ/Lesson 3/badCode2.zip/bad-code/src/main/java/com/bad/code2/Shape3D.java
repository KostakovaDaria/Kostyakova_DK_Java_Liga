package com.bad.code2;

public interface Shape3D {
    Double getX();
    Double getY();
    Double getZ();
    Double getVolume();
}
